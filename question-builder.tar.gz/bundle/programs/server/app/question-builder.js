(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// question-builder.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
                                                                       //
if (Meteor.isClient) {                                                 // 3
                                                                       //
    $.extend(Kh, KhanUtil);                                            // 6
    Meteor.subscribe("users");                                         // 7
                                                                       //
    Template.mainContent.helpers({                                     // 11
                                                                       //
        connectionStatus: function () {                                // 14
            return Meteor.status().status;                             // 15
        },                                                             //
        connectionClass: function () {                                 // 17
            if (Meteor.status().status == 'connected') {               // 18
                return "color:limegreen";                              // 19
            } else if (Meteor.status().status == 'connecting') {       //
                return "color:gray";                                   // 21
            } else {                                                   //
                return "color:red";                                    // 23
            }                                                          //
        }                                                              //
                                                                       //
    });                                                                //
                                                                       //
    Template.mainContent.events({                                      // 29
                                                                       //
        'click #CreateNew': function (e) {                             // 31
                                                                       //
            Session.set('questionMode', 'Create New');                 // 33
            Session.set('questionPreview', { text: "Enter the question text here.", answer: "Enter the answer text here." });
            Session.set('mqQuestionVars', [{ name: "var1", value: null, type: 'rand-int', index: 1, options: { min: -10, max: 10, exclude: "" } }]);
        }                                                              //
                                                                       //
    });                                                                //
                                                                       //
    Template.menuBar.helpers({                                         // 45
                                                                       //
        connectionStatus: function () {                                // 47
            return Meteor.status().status;                             // 48
        },                                                             //
        connectionClass: function () {                                 // 50
            if (Meteor.status().status == 'connected') {               // 51
                return "color:limegreen";                              // 52
            } else if (Meteor.status().status == 'connecting') {       //
                return "color:gray";                                   // 54
            } else {                                                   //
                return "color:red";                                    // 56
            }                                                          //
        }                                                              //
                                                                       //
    });                                                                //
                                                                       //
    Template.loggingIn.helpers({                                       // 66
                                                                       //
        isLoggingIn: Meteor.loggingIn                                  // 68
                                                                       //
    });                                                                //
                                                                       //
    Template.menuBar.events({                                          // 72
                                                                       //
        'click #navbar-brand': function () {                           // 74
                                                                       //
            Router.go('/');                                            // 76
        }                                                              //
                                                                       //
    });                                                                //
} //end client check                                                   //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=question-builder.js.map
